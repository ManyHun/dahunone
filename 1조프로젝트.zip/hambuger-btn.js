$('.buger-btn').click(function(ev){
    ev.preventDefault();

    $(this).toggleClass('active');
    $('.overlay').toggleClass('visible');
});
